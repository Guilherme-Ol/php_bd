<?php

require_once("modelo/ClientePF.php");
require_once("modelo/ClientePJ.php");
require_once("dao/ClienteDao.php");
require_once("util/Conexao.php");

//Teste da conexão com o banco
/*
require_once("util/Conexao.php");
$pdo = Conexao::getConexao();
print_r($pdo);
exit;
*/



do {
    echo "\n\n----CADASTRO DE CLIENTES----\n";
    echo "1- Cadastrar Cliente PF\n";
    echo "2- Cadastrar Cliente PJ\n";
    echo "3- Listar Clientes\n";
    echo "4- Buscar Cliente\n";
    echo "5- Excluir Cliente\n";
    echo "0- Sair\n";

    $opcao = readline("Informe a opção: ");
    switch ($opcao) {
        case 1:
            $cliente = new ClientePF();
            $cliente->setNomeSocial(readline("Informe o nome social: \n"));
            $cliente->setCpf(readline("Informe o CPF: \n"));
            $cliente->setEmail(readline("Informe o email: \n"));
            $cliente->setNome(readline("Informe o nome: \n"));

            $dao = new ClienteDao();
            $dao->inserir($cliente);
            print "Cliente PF inserido com sucesso!\n";
            break;

        case 2:
             $cliente = new ClientePJ();
            $cliente->setNomeSocial(readline("Informe o nome social: \n"));
            $cliente->setCnpj(readline("Informe o CNPJ: \n"));
            $cliente->setEmail(readline("Informe o email: \n"));
            $cliente->setRazaoSocial(readline("Informe a razão social: \n"));

            $dao = new ClienteDao();
            $dao->inserir($cliente);
            print "Cliente PJ inserido com sucesso!\n";
            break;

        case 3:
            $dao = new ClienteDao();
            $clientes = $dao->listar();
            //print_r($clientes);

            foreach ($clientes as $c) 
                echo $c . "\n";
            

            break;

        case 4:
            
            $id = readline("Informe o ID do cliente: \n");

            $dao = new ClienteDao();
            $cliente = $dao->buscarPorId($id);
            if($cliente != null){
                echo $cliente . "\n";
            } else
                echo "Cliente não encontrado.";

            break;

        case 5:
            $dao = new ClienteDao();
            $clientes = $dao->listar();
            foreach ($clientes as $c) 
                echo $c . "\n";
            $id = readline("Informe o ID do cliente que deseja excluir: \n");
            $clientes = $dao->excluirId($id);


            break;

        case 0:
            echo "Programa encerrado!\n";
            break;

        default:
            echo "Opção inválida!";
    }
} while($opcao != 0);
