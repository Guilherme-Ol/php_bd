<?php

require_once("modelo/Cliente.php");
require_once("modelo/ClientePF.php");
require_once("modelo/ClientePJ.php");

class ClienteDao
{

    public function inserir(Cliente $cliente)
    {
        $sql = "INSERT INTO clientes (tipo, nome_social, email, nome, cpf, razao_social, cnpj)
        Values 
        (?, ?, ?, ?, ?, ?, ?)";


        $conn = Conexao::getConexao();
        $stmt = $conn->prepare($sql);
        if ($cliente instanceof ClientePF) {
            $stmt->execute(array($cliente->getTipo(), $cliente->getNomeCompleto(), $cliente->getNomeSocial(), $cliente->getEmail(), $cliente->getCpf(), NULL, NULL));
        } else if ($cliente instanceof ClientePJ) {
            $stmt->execute(array($cliente->getTipo(), $cliente->getNomeSocial(), $cliente->getEmail(), NULL, NULL, $cliente->getRazaoSocial(), $cliente->getCnpj()));
        }
    }
    public function listar()
    {
        $sql = "SELECT * FROM clientes";
        $conn = Conexao::getConexao();
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $dados = $stmt->fetchAll();

        $clientes = $this->map($dados);
        return $clientes;
    }

    public function buscarPorId(int $idClientes)
    {
        $sql = "SELECT * FROM   clientes WHERE id = ?";
        $conn = Conexao::getConexao();
        $stmt = $conn->prepare($sql);
        $stmt->execute(array($idClientes));
        $dados = $stmt->fetchAll();

        $clientes = $this->map($dados);
        if(! empty($clientes))
            return $clientes[0];
        
            
            
        }
        private function map($dados){
            $clientes = array();
            foreach ($dados as $d) {
                $cliente = null;
                if ($d['tipo'] == 'F') {
                    $cliente = new ClientePF();
                    $cliente->setCpf($d["cpf"]);
                    $cliente->setNome($d["nome"]);
                } elseif ($d['tipo'] == 'J') {
                    $cliente = new ClientePJ();
                    $cliente->setRazaoSocial($d["razao_social"]);
                    $cliente->setCnpj($d["cnpj"]);
                }
                $cliente->setId($d["id"]);
                $cliente->setNomeSocial($d["nome_social"]);
                $cliente->setEmail($d["email"]);
                array_push($clientes, $cliente);
            }
            
            return $clientes;
        }

        public function excluirId($idClientes){
            $sql = "DELETE FROM   clientes WHERE id = ?";
        $conn = Conexao::getConexao();
        $stmt = $conn->prepare($sql);
        $stmt->execute(array($idClientes));
        $dados = $stmt->fetchAll();

        $clientes = $this->map($dados);
        if(! empty($clientes))
            return $clientes[0];
        }
    }

    